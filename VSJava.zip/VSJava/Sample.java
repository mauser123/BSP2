import java.io.*;
import java.net.*;
import java.util.*;
import java.nio.file.Files;
import java.nio.file.Paths;
public class Sample {
    public static void main(String[] args) throws IOException {
        String content = new String(Files.readAllBytes(Paths.get("123.txt")));
	System.out.println(content);
	File file = new File("123.txt");
	Scanner input = new Scanner(file);
	List<String> list = new ArrayList<String>();

while (input.hasNextLine()) {
    list.add(input.nextLine());
}
System.out.println(list.get(0));

    }
}
