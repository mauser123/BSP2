/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


import java.io.*;
import java.net.*;
import java.util.*;

/**
 *
 * @author markus
 */
 
public class WebServer {
    public void RunServer() {
        Thread udpThread = new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    udpServer();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
        Thread httpThread = new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    httpServer();
                } catch (Exception e) {
                    e.printStackTrace();
                };
            }
        });

       
        udpThread.start();
        httpThread.start();
        
    }
    public static void udpServer() {
        try {
            byte data[] = new byte[1024];
            DatagramPacket packet;
            DatagramSocket socket = new DatagramSocket(13131);
            System.out.println("TimeServer startet auf Port 13131");
            while (true) {
                // Auf Anfrage warten
                packet = new DatagramPacket(data, data.length);
                socket.receive(packet);
                // Empfänger auslesen, aber Paketinhalt ignorieren
                InetAddress address = packet.getAddress();
                int port = packet.getPort();
                String sentence = new String(packet.getData());
                System.out.println("RECEIVED: " + sentence);
                System.out.println(port);
                // Paket für Empfänger zusammenbauen
                String s = "Antwort auf Anfrage von " + address + " am Port "
                        + port + ": " + new Date().toString() + "\n";
                data = s.getBytes();
                packet = new DatagramPacket(data, data.length, address, port);
                socket.send(packet);
            }
        } catch (Exception e) {
            System.out.println(e);
        }
    }
    protected void httpServer() {
        ServerSocket s;
        System.out.println("Webserver starting up on port 8888");
        System.out.println("(press ctrl-c to exit)");
        try {
            // create the main server socket
            s = new ServerSocket(8888);
        } catch (Exception e) {
            System.out.println("Error: " + e);
            return;
        }
        
        System.out.println("Waiting for connection");
        for (;;) {
            try {
                String stats = "GET /stats HTTP/1.1";
                String fav = "GET /favicon.ico HTTP/1.1";
                String Get = "GET / HTTP/1.1";
                String auto ="Auto";
                boolean abc = false;
                // wait for a connection
                Socket remote = s.accept();
                // remote is now the connected socket
                System.out.println("Connection, sending data.");
                BufferedReader in = new BufferedReader(new InputStreamReader(
                remote.getInputStream()));
                PrintWriter out = new PrintWriter(remote.getOutputStream());
                //System.out.println(in.readLine());
                String str = ".";
                String tmp = in.readLine();
                System.out.print(tmp);
                
                if (tmp.contains(stats)) {
                    System.out.println(stats);
                    str = in.readLine();
                    while (!str.equals("")) {
                        System.out.println(str);
                        str = in.readLine();
                    }
                    out.println("HTTP/1.1 200 OK");
                    out.println("Content-Type: text/html");
                    out.println("Server: Bot");
                    // this blank line signals the end of the headers
                    out.println("");
                    // Send the HTML page
                    out.println("<H1>StatsPage!</H2>");
                    
                    out.flush();
                    remote.close();
                }
                if (tmp.contains(Get)) {
                    System.out.println(Get);
                    str = in.readLine();
                    while (!str.equals("")) {
                        System.out.println(str);
                        str = in.readLine();
                    }
                    out.println("HTTP/1.1 200 OK");
                    out.println("Content-Type: text/html");
                    out.println("Server: Bot");
                    // this blank line signals the end of the headers
                    out.println("");
                    // Send the HTML page
                    out.println("<H1>Hallo VS</H2>");
                    out.flush();
                    remote.close();
                } else {
                    out.println("HTTP/1.1 404 OK");
                    out.println("Content-Type: text/html");
                    out.println("Server: Bot");
                    // this blank line signals the end of the headers
                    out.println("");
                    // Send the HTML page
                    out.println("<H1>404 Not Found</H2>");
                    out.flush();
                    remote.close();
                }
            } catch (Exception e) {
                System.out.println("Error: " + e);
            }
        }
    }
    
    /**
     * Start the application.
     *
     * @param args Command line parameters are not used.
     */
    public static void main(String args[]) {
        WebServer ws = new WebServer();
        ws.RunServer();
        //ws.httpServer();
    }
}

