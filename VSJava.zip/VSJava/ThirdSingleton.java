import java.net.*;
import java.io.*;
import java.util.*;
public class ThirdSingleton  {  

        private static ThirdSingleton mInstance;
        private ArrayList<String> list = null;

        public static ThirdSingleton getInstance() {
            if(mInstance == null)
                mInstance = new ThirdSingleton();

            return mInstance;
        }

        private ThirdSingleton() {
          list = new ArrayList<String>();
        }
        // retrieve array from anywhere
        public ArrayList<String> getArray() {
         return this.list;
        }
        //Add element to array
        public void addToArray(String value) {
         list.add(value);
        }
	public int getSize() {
         return list.size();
        }
}
