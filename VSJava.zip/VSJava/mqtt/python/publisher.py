#!/usr/bin/python3

import time
import paho.mqtt.client as mqtt


def on_connect(client, userdata, flags, rc):
    """The callback for when the client connects to the server"""
    print('Connected with result code', str(rc))


# Create a MQTT client instance and set the on_connect callback
publisher = mqtt.Client()
publisher.on_connect = on_connect

# Connect to the MQTT broker
host = 'iot.eclipse.org'
port = 1883
publisher.connect(host, port)
print('Connecting to {} on port {}'.format(host, port))

# Start a new thread to process network traffic
publisher.loop_start()

while True:
    # Wait 2 seconds before a message is published
    time.sleep(2)

    # Publish the message
    topic = 'vs/test'
    message = 'Hello, world!'
    qos = 1
    publisher.publish(topic, message, qos)

    print('Published message {} in topic {}'.format(message, topic))
