#!/usr/bin/python3

import paho.mqtt.client as mqtt


def on_connect(client, userdata, flags, rc):
    """The callback for when the client connects to the server"""
    print('Connected with result code', str(rc))

    # When subscribing in on_connect(), the subscription will be renewed
    # after the connection is lost and reconnected
    client.subscribe('vs/test')


def on_message(client, userdata, message):
    """The callback for when a message is received from the server"""
    print('Message received')
    print('Message Topic:', message.topic)
    print('Message Payload:', message.payload.decode() + '\n')


# Create a MQTT client instance and set the on_connect and on_message callback
subscriber = mqtt.Client()
subscriber.on_connect = on_connect
subscriber.on_message = on_message

# Connect to the MQTT broker
host = 'iot.eclipse.org'
port = 1883
subscriber.connect(host, port)
print('Connecting to {} on port {}'.format(host, port))

# Blocking call that processes network traffic callbacks and handles reconnecting
subscriber.loop_forever()
