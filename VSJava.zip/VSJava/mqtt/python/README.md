# MQTT Publisher and Subscriber Example in Python 3

Author: Clemens Brockschmidt

## Requirements
1. Python 3 
	- If not installed, see the official [Python website](https://	www.python.org/downloads/). For resources on how to get started with 	Python visit the [beginner's guide](https://wiki.python.org/moin/	BeginnersGuide).
2. Eclipse Paho MQTT Python client. Install with
	
	```
	$ pip3 install paho-mqtt
	```


## Usage

1. Start the subscriber by executing 

	```
	$ python3 subscriber.py
	``` 

	in a terminal. The subscriber will now listen for messages in the topic `vs/test` on `iot.eclipse.org:1883` unless specified different inside `subscriber.py`.

3. To publish messages in the topic `vs/test`, start the publisher by executing

	```
	$ python3 publisher.py
	```
	
	 in another terminal. The publisher will now send the message _Hello, world!_ every 2 seconds.

4. Press `Ctrl+C` in the corresponding terminal to kill the subscriber or publisher.
