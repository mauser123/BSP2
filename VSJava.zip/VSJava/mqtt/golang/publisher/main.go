package main

import (
	"flag"

	"./publisher"
)

func main() {
	var brokerProtocol, brokerAddress, clientID, topic, message string
	var brokerPort int

	flag.StringVar(&brokerProtocol, "brokerProtocol", "tcp", "MQTT broker protocol")
	flag.StringVar(&brokerAddress, "brokerAddress", "localhost", "MQTT broker ip address or domain name")
	flag.IntVar(&brokerPort, "brokerPort", 1883, "MQTT broker port")
	flag.StringVar(&clientID, "clientID", "go-publisher1", "publisher client ID")
	flag.StringVar(&topic, "topic", "go-mqtt-test", "topic to publish message to")
	flag.StringVar(&message, "message", "Hello from publisher", "message to publish")
	flag.Parse()

	pub := publisher.NewPublisher(brokerProtocol, brokerAddress, brokerPort)
	pub.Run(clientID, topic, message)
}
