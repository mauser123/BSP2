package publisher

import (
	"fmt"
	"log"

	mqtt "github.com/eclipse/paho.mqtt.golang"
)

const (
	mqttQosBit = 2 // Quality of Service: exactly once
)

// MQTT publisher
type Publisher struct {
	brokerURI string
	options   *mqtt.ClientOptions
}

// creates new MQTT publisher
func NewPublisher(brokerProtocol string, brokerAddress string, brokerPort int) *Publisher {
	// create the broker string
	brokerURI := fmt.Sprintf("%s://%s:%d", brokerProtocol, brokerAddress, brokerPort)

	// create subscriber instance
	s := &Publisher{
		brokerURI: brokerURI,
		options:   mqtt.NewClientOptions().AddBroker(brokerURI),
	}

	return s
}

// starts the publisher
func (s *Publisher) Run(clientID string, topic string, message string) {
	client := mqtt.NewClient(s.options.SetClientID(clientID))

	// Connect to MQTT broker
	if token := client.Connect(); token.Wait() && token.Error() != nil {
		panic(token.Error())
	}
	defer client.Disconnect(0)
	log.Printf("Connected to MQTT broker: %s\n", s.brokerURI)

	// Subscribe to a topic
	if token := client.Publish(topic, mqttQosBit, false, message); token.Wait() && token.Error() != nil {
		panic(token.Error())
	}
	log.Printf("Published message: %s\n", message)
}
