MQTT Client example in Go
using [eclipse/paho.mqtt.golang](https://github.com/eclipse/paho.mqtt.golang) library

Building and Usage:

0. Install Go, see [docs](https://golang.org/) and MQTT (Keyword: Mosquito, see one directory up)

1. If necessary, install Paho packages with `go get github.com/eclipse/paho.mqtt.golang`.

2. Build project with `make` on command line

2. Start MQTT Subscriber with `./bin/subscriber -brokerAddress <ip>` (default broker address is `127.0.0.1`, for help execute `./bin/subscriber -help`)

3. Publish message with `./bin/publisher -brokerAddress <ip> -message 'Hello World!'` (for help execute `./bin/publisher -help`)