package subscriber

import (
	"fmt"
	"log"
	"sync"

	mqtt "github.com/eclipse/paho.mqtt.golang"
)

const (
	mqttQosBit = 2 // Quality of Service: exactly once
)

// MQTT subscriber
type Subscriber struct {
	brokerURI string
	options   *mqtt.ClientOptions
}

// creates a new MQTT subscriber
func NewSubscriber(brokerProtocol string, brokerAddress string, brokerPort int) *Subscriber {
	// create the broker string
	brokerURI := fmt.Sprintf("%s://%s:%d", brokerProtocol, brokerAddress, brokerPort)

	// create subscriber instance
	s := &Subscriber{
		brokerURI: brokerURI,
		options:   mqtt.NewClientOptions().AddBroker(brokerURI),
	}

	return s
}

// starts the subscriber
func (s *Subscriber) Run(clientID string, topic string) {
	client := mqtt.NewClient(s.options.SetClientID(clientID))

	// Connect to MQTT broker
	if token := client.Connect(); token.Wait() && token.Error() != nil {
		panic(token.Error())
	}
	defer client.Disconnect(0)
	log.Printf("Connected to MQTT broker: %s\n", s.brokerURI)

	// Subscribe to a topic
	if token := client.Subscribe(topic, mqttQosBit, simpleMessageHandler); token.Wait() && token.Error() != nil {
		panic(token.Error())
	}
	defer client.Unsubscribe()
	log.Printf("Subscribed to topic: %s\n", topic)

	// block until process is canceled
	var wg sync.WaitGroup
	wg.Add(1)
	wg.Wait()
}
