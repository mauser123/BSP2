package subscriber

import (
	"log"

	mqtt "github.com/eclipse/paho.mqtt.golang"
)

// message hander that prints the payload of received messages to logger
func simpleMessageHandler(client mqtt.Client, message mqtt.Message) {
	log.Printf("Message received: %s\n", message.Payload())
}
