package main

import (
	"flag"

	"./subscriber"
)

func main() {
	var brokerProtocol, brokerAddress, clientID, topic string
	var brokerPort int

	flag.StringVar(&brokerProtocol, "brokerProtocol", "tcp", "MQTT broker protocol")
	flag.StringVar(&brokerAddress, "brokerAddress", "localhost", "MQTT broker ip address or domain name")
	flag.IntVar(&brokerPort, "brokerPort", 1883, "MQTT broker port")
	flag.StringVar(&clientID, "clientID", "go-subscriber1", "subscriber client ID")
	flag.StringVar(&topic, "topic", "go-mqtt-test", "topic to subscribe to")
	flag.Parse()

	subs := subscriber.NewSubscriber(brokerProtocol, brokerAddress, brokerPort)
	subs.Run(clientID, topic)
}
