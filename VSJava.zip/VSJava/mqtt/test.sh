#!/bin/bash
#
# run as root
 

echo "Starting MQTT service"
sudo service mosquitto start

echo "Subscribung to test/topic for one message"
echo "(in background to prevent blocking the shell)"
mosquitto_sub -v -C 1 -t 'test/topic' &
sleep 1 #short sleep to get prints in right order

echo "Publishing on test/topic"
mosquitto_pub -t 'test/topic' -m 'helloWorld'

echo "Stopping MQTT service"
sudo service mosquitto stop



