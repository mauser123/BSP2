import java.net.*;
import java.io.*;
import java.util.*;
import org.eclipse.paho.client.mqttv3.IMqttDeliveryToken;
import org.eclipse.paho.client.mqttv3.MqttAsyncClient;
import org.eclipse.paho.client.mqttv3.MqttCallback;
import org.eclipse.paho.client.mqttv3.MqttConnectOptions;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.MqttMessage;
import org.eclipse.paho.client.mqttv3.persist.MemoryPersistence;

public class SecondManuServer implements MqttCallback  {

  public void RunServer() {
        Thread udpThread = new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    udpServer();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    
        udpThread.start();
           }
public void udpServer(){
mqttSubscribe();
try
 {
 byte data[] = new byte[1024];
 DatagramPacket packet;
 DatagramSocket socket = new DatagramSocket(5555);
 System.out.println("TimeServer startet auf Port 5555");
 while ( true )
 {
 // Auf Anfrage warten
 packet = new DatagramPacket(data, data.length);
 socket.receive(packet);
 // Empfänger auslesen, aber Paketinhalt ignorieren
 InetAddress address = packet.getAddress();
 int port = packet.getPort();
 // Paket für Empfänger zusammenbauen
 String s = "Antwort auf Anfrage von "+address+" am Port "
 +port+": "+new Date().toString() + "\n";
 data = s.getBytes();
 packet = new DatagramPacket(data,data.length,address,port);
 socket.send(packet);
 }
 }
 catch (Exception e)
 { System.out.println(e); }
}
public void wTxt(String tmp) {
       
              try{
       PrintWriter outputStream = new PrintWriter(new FileOutputStream("SecondManu.txt", true));

       outputStream.println(tmp);
       outputStream.close();

       }catch (FileNotFoundException e){
           e.printStackTrace();
       }
    }
public void mqttSubscribe(){
        String topic = "MQTT Examples";
        int qos = 2;
        String broker = "tcp://localhost:1883";
        String clientId = "SecondManuServer";
        MemoryPersistence persistence = new MemoryPersistence();

        try {
            MqttAsyncClient sampleClient = new MqttAsyncClient(broker, clientId, persistence);
            MqttConnectOptions connOpts = new MqttConnectOptions();
            connOpts.setCleanSession(true);
            sampleClient.setCallback(new SecondManuServer());
            System.out.println("Connecting to broker: " + broker);
            sampleClient.connect(connOpts);
            System.out.println("Connected");
            Thread.sleep(1000);
            sampleClient.subscribe(topic, qos);
            System.out.println("Subscribed");
        } catch (Exception me) {
            if (me instanceof MqttException) {
                System.out.println("reason " + ((MqttException) me).getReasonCode());
            }
            System.out.println("msg " + me.getMessage());
            System.out.println("loc " + me.getLocalizedMessage());
            System.out.println("cause " + me.getCause());
            System.out.println("excep " + me);
            me.printStackTrace();
        }
    }

    public void connectionLost(Throwable arg0) {
        System.err.println("connection lost");

    }

    public void deliveryComplete(IMqttDeliveryToken arg0) {
        System.err.println("delivery complete");
    }

    public void messageArrived(String topic, MqttMessage message) throws Exception {
         
        System.out.println("topic: " + topic);
        System.out.println("message: " + new String(message.getPayload()));
 	SecondSingleton.getInstance().addToArray(new String(message.getPayload()));
	
	System.out.println(SecondSingleton.getInstance().getSize()); 
        wTxt(new String(message.getPayload()));

    }

public static void main(String[] args) throws FileNotFoundException {
        Scanner s = new Scanner(new File("SecondManu.txt"), "utf-8");
        while (s.hasNextLine()){
     SecondSingleton.getInstance().addToArray(s.nextLine()); 

}
    System.out.println(SecondSingleton.getInstance().getSize()); 
s.close();
SecondManuServer ks = new SecondManuServer();
ks.RunServer();
}
}

