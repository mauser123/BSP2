/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.*;
import java.net.*;
import java.util.*;
import java.util.concurrent.TimeUnit;
import org.eclipse.paho.client.mqttv3.MqttClient;
import org.eclipse.paho.client.mqttv3.MqttConnectOptions;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.MqttMessage;
import org.eclipse.paho.client.mqttv3.persist.MemoryPersistence;

/**
 *
 * @author markus
 */
public class Zentrale_BUS {

   
    

    public void RunServer() {
        Thread udpThread = new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    udpServer();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
        Thread httpThread = new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    httpServer();
                } catch (Exception e) {
                    e.printStackTrace();
                };
            }
        });
    

        udpThread.start();
        httpThread.start();

    }

    public void udpServer() {
        String carType = "LKW";
        try {
            byte data[] = new byte[1024];
            DatagramPacket packet;
            DatagramSocket socket = new DatagramSocket(7778);
            System.out.println("TimeServer startet auf Port 7778");
            while (true) {
                // Auf Anfrage warten
                packet = new DatagramPacket(data, data.length);
                socket.receive(packet);
                // Empfänger auslesen, aber Paketinhalt ignorieren
                InetAddress address = packet.getAddress();
                int port = packet.getPort();
                String sentence = new String(packet.getData());
                System.out.println("RECEIVED: " + sentence);
                System.out.println(port);
               mqttPublish(carType+" "+sentence);
            }
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    protected void httpServer() {
        ServerSocket s;
        System.out.println("Webserver starting up on port 7777");
        System.out.println("(press ctrl-c to exit)");
        try {
            // create the main server socket
            s = new ServerSocket(7);
        } catch (Exception e) {
            System.out.println("Error: " + e);
            return;
        }

        System.out.println("Waiting for connection");
        for (;;) {
            try {
                String stats = "GET /stats HTTP/1.1";
                String fav = "GET /favicon.ico HTTP/1.1";
                String Get = "GET / HTTP/1.1";
                String auto = "Auto";
                boolean abc = false;
                // wait for a connection
                Socket remote = s.accept();
                // remote is now the connected socket
                System.out.println("Connection, sending data.");
                BufferedReader in = new BufferedReader(new InputStreamReader(
                        remote.getInputStream()));
                PrintWriter out = new PrintWriter(remote.getOutputStream());
                //System.out.println(in.readLine());
                String str = ".";
                String tmp = in.readLine();
                System.out.print(tmp);

                if (tmp.contains(stats)) {
                    System.out.println(stats);
                    str = in.readLine();
                    while (!str.equals("")) {
                        System.out.println(str);
                        str = in.readLine();
                    }
                    out.println("HTTP/1.1 200 OK");
                    out.println("Content-Type: text/html");
                    out.println("Server: Bot");
                    // this blank line signals the end of the headers
                    out.println("");
                    // Send the HTML page
                    out.println("<H1>StatsPage!</H2>");

                    out.flush();
                    remote.close();
                }
                if (tmp.contains(Get)) {
                    System.out.println(Get);
                    str = in.readLine();
                    while (!str.equals("")) {
                        System.out.println(str);
                        str = in.readLine();
                    }
                    out.println("HTTP/1.1 200 OK");
                    out.println("Content-Type: text/html");
                    out.println("Server: Bot");
                    // this blank line signals the end of the headers
                    out.println("");
                    // Send the HTML page
                    out.println("<H1>Hallo VS</H2>");
                    out.flush();
                    remote.close();
                } else {
                    out.println("HTTP/1.1 404 OK");
                    out.println("Content-Type: text/html");
                    out.println("Server: Bot");
                    // this blank line signals the end of the headers
                    out.println("");
                    // Send the HTML page
                    out.println("<H1>404 Not Found</H2>");
                    out.flush();
                    remote.close();
                }
            } catch (Exception e) {
                System.out.println("Error: " + e);
            }
        }
    }

    public void mqttPublish(String tmp) {

        String topic = "MQTT Examples";
        //String content      = "Message from MqttPublishSample";
        //String content1      = "Content1";
        //String content2      = "Content2";
        String content = tmp;
        int qos = 2;
        String broker = "tcp://localhost:1883";
        String clientId = "JavaSample";
        MemoryPersistence persistence = new MemoryPersistence();

        try {
            
            MqttClient sampleClient = new MqttClient(broker, clientId, persistence);
            MqttConnectOptions connOpts = new MqttConnectOptions();
            connOpts.setCleanSession(true);
            System.out.println("Connecting to broker: " + broker);
            sampleClient.connect(connOpts);
            System.out.println("Connected");
            System.out.println("Publishing message: " + content);
            MqttMessage message = new MqttMessage(content.getBytes());
            message.setQos(qos);
            sampleClient.publish(topic, message);
            System.out.println("Message published");
            sampleClient.disconnect();
            System.out.println("Disconnected");
            tmp = "";
           // System.exit(0);

        } catch (MqttException me) {
            System.out.println("reason " + me.getReasonCode());
            System.out.println("msg " + me.getMessage());
            System.out.println("loc " + me.getLocalizedMessage());
            System.out.println("cause " + me.getCause());
            System.out.println("excep " + me);
            me.printStackTrace();
        }
    }

    /**
     * Start the application.
     *
     * @param args Command line parameters are not used.
     */
    public static void main(String args[]) {
        Zentrale_BUS  ws = new Zentrale_BUS();
        ws.RunServer();
        //ws.httpServer();
    }
}

