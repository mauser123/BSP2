/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.*;
import java.net.*;
import java.util.*;
import java.util.concurrent.TimeUnit;
import org.eclipse.paho.client.mqttv3.MqttClient;
import org.eclipse.paho.client.mqttv3.MqttConnectOptions;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.MqttMessage;
import org.eclipse.paho.client.mqttv3.persist.MemoryPersistence;

/**
 *
 * @author markus
 */
public class Zentrale_LKW {

public static void write(String inhalt){	
		try {
			File file = new File("Data.txt");
			FileWriter fileWriter = new FileWriter(file);
			fileWriter.write(inhalt);
			fileWriter.flush();
			fileWriter.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}  
 
    public void RunServer() {
        Thread udpThread = new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    udpServer();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
        Thread httpThread = new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    httpServer();
                } catch (Exception e) {
                    e.printStackTrace();
                };
            }
        });
       Thread mqttThread = new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    mqttPublish();
                } catch (Exception e) {
                    e.printStackTrace();
                };
            }
        });

        udpThread.start();
        httpThread.start();
        mqttThread.start();

    }

    public void udpServer() {
	String carType = "LKW ";
        String kmh = "KMH: 60";
	String tacho = "THO: 123";
	String verkehrslage ="VKL: Stau";
	String tank = "TNK: 100";
	String tempString = "";


        try {
            byte data[] = new byte[1024];
            DatagramPacket packet;
            DatagramSocket socket = new DatagramSocket(8889);
            System.out.println("TimeServer startet auf Port 8889");
            while (true) {
                // Auf Anfrage warten
                packet = new DatagramPacket(data, data.length);
                socket.receive(packet);
                // Empfänger auslesen, aber Paketinhalt ignorieren
                InetAddress address = packet.getAddress();
                int port = packet.getPort();
                String sentence = new String(packet.getData(),0,packet.getLength());
		
                System.out.println("RECEIVED: " + sentence);
		

		if(sentence.substring(0,2).equals("KM")){
		kmh = sentence;
		
		}
		else if(sentence.substring(0,2).equals("TN")){
		tank = sentence;

		}
		else if(sentence.substring(0,2).equals("VK")){
		verkehrslage = sentence;
		
		}
		else if(sentence.substring(0,2).equals("TH")){
		tacho = sentence;
		
		}
		tempString =carType+kmh+" "+tacho+" "+verkehrslage+" "+" "+tank;
		ZentraleSingleton.getInstance().addToList(tempString);
		System.out.println(ZentraleSingleton.getInstance().getSize()); 
	        write(tempString);

		System.out.println(tempString);
               	//mqttPublish(carType+" "+sentence);
            }
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    protected void httpServer() {
        ServerSocket s;
        System.out.println("Webserver starting up on port 8888");
        System.out.println("(press ctrl-c to exit)");
        try {
            // create the main server socket
            s = new ServerSocket(8888);
        } catch (Exception e) {
            System.out.println("Error: " + e);
            return;
        }

        System.out.println("Waiting for connection");
        for (;;) {
            try {
                String stats = "GET /stats HTTP/1.1";
                String fav = "GET /favicon.ico HTTP/1.1";
                String Get = "GET / HTTP/1.1";
                String auto = "Auto";
                boolean abc = false;
                // wait for a connection
                Socket remote = s.accept();
                // remote is now the connected socket
                System.out.println("Connection, sending data.");
                BufferedReader in = new BufferedReader(new InputStreamReader(
                        remote.getInputStream()));
                PrintWriter out = new PrintWriter(remote.getOutputStream());
                //System.out.println(in.readLine());
                String str = ".";
                String tmp = in.readLine();
                System.out.print(tmp);

                if (tmp.contains(stats)) {
                    System.out.println(stats);
                    str = in.readLine();
                    while (!str.equals("")) {
                        System.out.println(str);
                        str = in.readLine();
                    }
                    out.println("HTTP/1.1 200 OK");
                    out.println("Content-Type: text/html");
                    out.println("Server: Bot");
                    // this blank line signals the end of the headers
                    out.println("");
                    // Send the HTML page
                    out.println("<H1>StatsPage!</H2>");

                    out.flush();
                    remote.close();
                }
                if (tmp.contains(Get)) {
                    System.out.println(Get);
                    str = in.readLine();
                    while (!str.equals("")) {
                        System.out.println(str);
                        str = in.readLine();
                    }
                    out.println("HTTP/1.1 200 OK");
                    out.println("Content-Type: text/html");
                    out.println("Server: Bot");
                    // this blank line signals the end of the headers
                    out.println("");
                    // Send the HTML page
                    out.println("<H1>Hallo VS</H2>");
                    out.flush();
                    remote.close();
                } else {
                    out.println("HTTP/1.1 404 OK");
                    out.println("Content-Type: text/html");
                    out.println("Server: Bot");
                    // this blank line signals the end of the headers
                    out.println("");
                    // Send the HTML page
                    out.println("<H1>404 Not Found</H2>");
                    out.flush();
                    remote.close();
                }
            } catch (Exception e) {
                System.out.println("Error: " + e);
            }
        }
    }

    //public void mqttPublish(String tmp) {
 	public void mqttPublish() throws InterruptedException{
        
	String topic = "MQTT Examples";
	ZentraleSingleton.getInstance().addToList("LKW KMH: 60 THO: 123 VKL: Stau TNK: 100");
	while(true){
       
        int qos = 2;
        String broker = "tcp://localhost:1883";
        String clientId = "JavaSample";
        MemoryPersistence persistence = new MemoryPersistence();

        try {
            String content = ZentraleSingleton.getInstance().getArray().getLast();
            MqttClient sampleClient = new MqttClient(broker, clientId, persistence);
            MqttConnectOptions connOpts = new MqttConnectOptions();
            connOpts.setCleanSession(true);
            System.out.println("Connecting to broker: " + broker);
            sampleClient.connect(connOpts);
            System.out.println("Connected");
            System.out.println("Publishing message: " + content);
            MqttMessage message = new MqttMessage(content.getBytes());	
            message.setQos(qos);
            sampleClient.publish(topic, message);
	    System.out.println("Messages published");
            sampleClient.disconnect();
            System.out.println("Disconnected from Broker!");
	    
            TimeUnit.SECONDS.sleep(5);
	    

           // System.exit(0);

        } catch (MqttException me) {
            System.out.println("reason " + me.getReasonCode());
            System.out.println("msg " + me.getMessage());
            System.out.println("loc " + me.getLocalizedMessage());
            System.out.println("cause " + me.getCause());
            System.out.println("excep " + me);
            
	    //e.printStackTrace();
        }
    }}

    /**
     * Start the application.
     *
     * @param args Command line parameters are not used.
     */
    public static void main(String args[]) {
        Zentrale_LKW ws = new Zentrale_LKW();
        ws.RunServer();
        //ws.httpServer();
    }
}

