
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <netdb.h>
#include <sys/socket.h>
#include "port.h"
#include <unistd.h>

#define BUFLEN 2048
#define MSGS 5	/* number of messages to send */


int main(void)
{	
	struct sockaddr_in myaddr, remaddr;
	int fd,i=0, slen=sizeof(remaddr);
	double tank = 100.00;
	char buf[BUFLEN];	/* message buffer */
	int recvlen;		/* # bytes in acknowledgement message */
	char *server = "127.0.0.1";	/* change this to use a different server */

	/* create a socket */

	if ((fd=socket(AF_INET, SOCK_DGRAM, 0))==-1)
		printf("socket created\n");

	/* bind it to all local addresses and pick any port number */

	memset((char *)&myaddr, 0, sizeof(myaddr));
	myaddr.sin_family = AF_INET;
	myaddr.sin_addr.s_addr = htonl(INADDR_ANY);
	myaddr.sin_port = htons(0);

	if (bind(fd, (struct sockaddr *)&myaddr, sizeof(myaddr)) < 0) {
		perror("bind failed");
		return 0;
	}       

	
	memset((char *) &remaddr, 0, sizeof(remaddr));
	remaddr.sin_family = AF_INET;
	remaddr.sin_port = htons(SERVICE_PORT);
	if (inet_aton(server, &remaddr.sin_addr)==0) {
		fprintf(stderr, "inet_aton() failed\n");
		exit(1);
	}

		
		while(1){
		int r = rand()%100;
    if(r >= 90){
    tank-=2.2;
    }
    else if((r <= 89) && (r >=70)){
    tank-=1.5;   
    }
    else if((r <= 69) && (r >=40)){
    tank-=1.0;    
    }
    else if((r <= 39) && (r >=0)){
    tank-=0.5;    
    }
    if(tank <= 0.00){
        printf("Tank ist leer!\n");
        return 0;
    }
		i++;
		printf("Sending packet %d to %s port %d contains: %lf\n", i, server, SERVICE_PORT,tank);
		sprintf(buf, "TNK: %lf", tank);
		if (sendto(fd, buf, strlen(buf), 0, (struct sockaddr *)&remaddr, slen)==-1) {
			perror("sendto");
			exit(1);
		}
	FILE *f = fopen("tank.txt", "a+");
		if (f == NULL)
		{
   		 printf("Error opening file!\n");
   		 exit(1);
		}		
		/* print some text */
		fprintf(f, "Ihr tank ist zu %lf prozent voll\n", tank);
		fclose(f);	
	sleep(1);
	}
	close(fd);
	return 0;
}

