
/* SERVIVE_PORT defines the default port number for this service 
 * replace the number with a unique number > 1024
 * a reasonable number may be obtained from, say, four
 * digits of your id + 1024
 */

//#define SERVICE_PORT	7778	/* hard-coded port number for BUS*/

//#define SERVICE_PORT	8889	/* hard-coded port number for LKW*/
#define SERVICE_PORT	6667	/* hard-coded port number for PKW*/

//#define SERVICE_PORT	13131	/* TST*/
