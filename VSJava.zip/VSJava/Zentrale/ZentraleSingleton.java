import java.net.*;
import java.io.*;
import java.util.*;
public class ZentraleSingleton  {  

        private static ZentraleSingleton mInstance;
        private LinkedList<String> list = null;

        public static ZentraleSingleton getInstance() {
            if(mInstance == null)
                mInstance = new ZentraleSingleton();

            return mInstance;
        }

        private ZentraleSingleton() {
          list = new LinkedList<String>();
        }
        // retrieve array from anywhere
        public LinkedList<String> getArray() {
         return this.list;
        }
        //Add element to array
        public void addToList(String value) {
         list.add(value);
        }
	public int getSize() {
         return list.size();
        }
}
